import soapui.com.jayway.jsonpath.*
import com.eviware.soapui.support.types.StringToStringsMap 

/* Enter the test_suite/test_case/test_step name of Stateful API's*/
testSuite="TS-PMCAPITesting"
testCaseName="TC-Token"
testStepName="postfortoken"
jsonPathResponse= "accessToken"

/* Header name to be added in the other request*/
inputRequestHeader = "Authorization"

ignoreTestSuites="Automation_Test_Suite,TS-PMCAPITesting"

/*Run the Stateful API */
def teststep = testRunner.testCase.testSuite.project.testSuites[testSuite].testCases[testCaseName].testSteps[testStepName]
def response
try{
	def runner = teststep.run(testRunner, context)
	response= runner.response.contentAsString
}catch(Exception e){
	log.info e
}
//Parsing JSON response using JsonParse class imported from json-path.jar file
def jsonParse
	try{
		jsonParse = new JsonParse(response)
	}catch(Exception){
		log.info e
	}

def jsonValue  = jsonParse.getJsonValue(jsonPathResponse)

def headers = new StringToStringsMap()

headers.put(inputRequestHeader,"Bearer "+jsonValue)
headers.put("Content-Type","application/json; charset=utf-8")
  		
testSuites = testRunner.testCase.testSuite.project.getTestSuiteList()

testSuite:
for(ts in testSuites)
{
	for(ts_ignore in ignoreTestSuites.split(","))
	{
		if(ts.name==ts_ignore){continue testSuite}
	}
	testCases = testRunner.testCase.testSuite.project.testSuites[ts.name].getTestCaseList()
				
	for(tc in testCases)
	{
		testSteps = testRunner.testCase.testSuite.project.testSuites[ts.name].testCases[tc.name].getTestStepList()
				
		for(tstep in testSteps)
		{		
			tstep.testRequest.setRequestHeaders(headers)
			log.info "${tstep.name} is updated with ${headers}"
			//log.info tstep.name
		}
	}
	
}
